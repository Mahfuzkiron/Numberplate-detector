import cv2

cascade_file = cv2.CascadeClassifier(
    'E:\\opencv\\opencv exercise\\5. numberplate detector\\russian_number_plate.xml')
cap = cv2.VideoCapture(0)
count = 0

while True:
    success, img = cap.read()
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    numberPlates = cascade_file.detectMultiScale(imgGray, 1.1, 10)
    for (x, y, w, h) in numberPlates:
        area = w * h
        if area > 200:
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), 2)
            cv2.putText(img, "Number Plate", (x, y - 5),
                        cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 255), 2)
            img_Roi = img[y:y + h, x:x + w]
            cv2.imshow("ROI", img_Roi)

    cv2.imshow("Result", img)

    if cv2.waitKey(1) & 0xFF == ord('s'):
        resize_img = cv2.resize(img_Roi, (450, 250))
        cv2.imwrite("resources\\test1" + str(count) + ".jpg", resize_img)

        cv2.imshow("Result", img)
        cv2.waitKey(500)
        count += 1
